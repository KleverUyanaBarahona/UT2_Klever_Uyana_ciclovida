package com.example.proyecto_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class MainActivity extends Activity {
    public int contador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        android.util.Log.i(TAG, "onCreate");
    if(savedInstanceState != null) {
        contador = savedInstanceState.getInt("contador");
        mostrarResultado();
    }
    else
        {
        contador = 0;
        mostrarResultado();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        android.util.Log.i(TAG, "onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        android.util.Log.i(TAG, "onRestart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        android.util.Log.i(TAG, "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        android.util.Log.i(TAG, "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        android.util.Log.i(TAG, "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        android.util.Log.i(TAG, "onDestroy");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt("contador",contador);
        super.onSaveInstanceState(outState);
    }

    public void incrementaContador(View vista){
        contador++;
        mostrarResultado();
    }

    public void restaContador(View vista){
        contador--;
        mostrarResultado();
    }
    public void resetearContador(View vista){
        contador=0;
        mostrarResultado();
    }
    public void mostrarResultado(){
        TextView textoResultado=(TextView)findViewById(R.id.contadorPulsaciones);
        textoResultado.setText("Contador: "+contador);
    }
private static final String TAG = "CicloDeVida";
}
